import 'dart:async';
import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;

import '../models/video.dart' as app_models;
import '../services/auth_service.dart';
import '../services/session_manager.dart';
import '../theme/reem_theme.dart';
import '../utils/date_labels.dart';
import '../utils/media_url.dart';
import '../widgets/video_player_item.dart';
import '../widgets/video_thumbnail.dart';

/// Conversation façon WhatsApp : bulles, heure sur chaque message,
/// séparateurs « Aujourd'hui », « Hier », jour de la semaine…
class ChatScreen extends StatefulWidget {
  final int? conversationId;
  final int? otherUserId;
  final String? otherUserName;

  const ChatScreen({
    Key? key,
    this.conversationId,
    this.otherUserId,
    this.otherUserName,
  }) : super(key: key);

  @override
  State<ChatScreen> createState() => _ChatScreenState();
}

class _ChatScreenState extends State<ChatScreen> {
  final SessionManager _sessionManager = SessionManager();
  final TextEditingController _messageController = TextEditingController();
  final ScrollController _scroll = ScrollController();
  Timer? _refreshTimer;

  bool _isLoading = true;
  bool _isSending = false;
  int? _conversationId;
  List<dynamic> _messages = [];
  String? _otherUserName;
  String? _otherUserPhoto;

  Map<String, String> get _headers => {
        'Authorization': 'Bearer ${_sessionManager.authToken}',
        'Content-Type': 'application/json',
        'Accept': 'application/json',
      };

  @override
  void initState() {
    super.initState();
    _conversationId = widget.conversationId;
    _otherUserName = widget.otherUserName;
    _messageController.addListener(() => setState(() {}));
    _initializeConversation();
    // Les nouveaux messages arrivent sans quitter l'écran
    _refreshTimer = Timer.periodic(const Duration(seconds: 6), (_) {
      if (!_isSending) _loadConversation(silent: true);
    });
  }

  @override
  void dispose() {
    _refreshTimer?.cancel();
    _messageController.dispose();
    _scroll.dispose();
    super.dispose();
  }

  Future<void> _initializeConversation() async {
    if (!_sessionManager.isAuthenticated) {
      setState(() => _isLoading = false);
      return;
    }

    if (_conversationId != null) {
      await _loadConversation();
      return;
    }

    if (widget.otherUserId != null) {
      try {
        final response = await http.post(
          Uri.parse('${AuthService.baseUrl}/conversations'),
          headers: _headers,
          body: jsonEncode({'other_user_id': widget.otherUserId}),
        );

        if (response.statusCode == 200) {
          final conversation = jsonDecode(response.body);
          setState(() {
            _conversationId = conversation['id'];
            _applyParticipants(conversation['participants']);
          });
          await _loadConversation();
          return;
        }
      } catch (_) {}
    }
    if (mounted) setState(() => _isLoading = false);
  }

  void _applyParticipants(List<dynamic>? participants) {
    if (participants == null || participants.isEmpty) return;
    final currentUserId = _sessionManager.currentUser?['id'];
    final other = participants.firstWhere(
      (participant) => participant['id'] != currentUserId,
      orElse: () => participants.first,
    );
    _otherUserName = widget.otherUserName ?? other['name']?.toString() ?? 'Discussion';
    _otherUserPhoto = other['profile_photo_path']?.toString();
  }

  Future<void> _loadConversation({bool silent = false}) async {
    if (_conversationId == null) return;

    if (!silent) setState(() => _isLoading = true);
    try {
      final response = await http.get(
        Uri.parse('${AuthService.baseUrl}/conversations/$_conversationId'),
        headers: _headers,
      );

      if (response.statusCode == 200 && mounted) {
        final conversation = jsonDecode(response.body);
        final incoming = List<dynamic>.from(conversation['messages'] ?? []);
        setState(() {
          _messages = incoming;
          _applyParticipants(conversation['participants']);
        });
      }
    } catch (_) {}
    if (mounted && !silent) setState(() => _isLoading = false);
  }

  Future<void> _sendMessage() async {
    final body = _messageController.text.trim();
    if (_conversationId == null || body.isEmpty || _isSending) return;

    setState(() => _isSending = true);
    try {
      final response = await http.post(
        Uri.parse('${AuthService.baseUrl}/conversations/$_conversationId/messages'),
        headers: _headers,
        body: jsonEncode({'body': body}),
      );

      if (response.statusCode == 201 && mounted) {
        final message = jsonDecode(response.body);
        setState(() {
          _messages.add(message);
          _messageController.clear();
        });
        if (_scroll.hasClients) _scroll.jumpTo(0); // la liste est inversée : 0 = dernier message
      } else if (mounted) {
        _toast('Message non envoyé. Réessaie.');
      }
    } catch (_) {
      _toast('Message non envoyé. Vérifie ta connexion.');
    }
    if (mounted) setState(() => _isSending = false);
  }

  void _toast(String message) {
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(message)));
  }

  // ---------------------------------------------------------------------------
  // CONTENU DES MESSAGES
  // ---------------------------------------------------------------------------

  Widget _buildMessageContent(String body, bool fromMe) {
    final textColor = fromMe ? Colors.white : context.reem.text;
    const marker = 'REEM_VIDEO:';

    if (!body.startsWith(marker)) {
      return Text(body, style: TextStyle(color: textColor, fontSize: 15, height: 1.3));
    }

    try {
      final shared = jsonDecode(body.substring(marker.length)) as Map<String, dynamic>;
      final videoUrl = shared['video_url']?.toString() ?? '';
      final video = app_models.Video(
        id: shared['id'] as int,
        videoUrl: videoUrl,
        title: shared['title']?.toString() ?? 'Vidéo partagée',
        description: shared['description']?.toString(),
        username: shared['username']?.toString() ?? 'Utilisateur',
        authorId: shared['author_id'] as int? ?? 0,
        likesCount: shared['likes_count'] as int? ?? 0,
        commentsCount: shared['comments_count'] as int? ?? 0,
        isLiked: false,
        isFavorited: false,
      );

      return InkWell(
        onTap: () => Navigator.push(
          context,
          MaterialPageRoute(
            builder: (_) => Scaffold(
              backgroundColor: Colors.black,
              body: VideoPlayerItem(video: video, feedVisible: ValueNotifier<bool>(true)),
            ),
          ),
        ),
        borderRadius: BorderRadius.circular(12),
        child: SizedBox(
          width: 220,
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              ClipRRect(
                borderRadius: BorderRadius.circular(10),
                child: SizedBox(
                  height: 190,
                  child: VideoThumbnail(thumbnailUrl: '', videoUrl: videoUrl),
                ),
              ),
              const SizedBox(height: 8),
              Text(
                video.title,
                maxLines: 2,
                overflow: TextOverflow.ellipsis,
                style: TextStyle(color: textColor, fontWeight: FontWeight.w700),
              ),
              Text(
                'Vidéo de @${video.username} · Appuyer pour regarder',
                maxLines: 1,
                overflow: TextOverflow.ellipsis,
                style: TextStyle(color: textColor.withValues(alpha: 0.7), fontSize: 12),
              ),
            ],
          ),
        ),
      );
    } catch (_) {
      return Text('Vidéo partagée', style: TextStyle(color: textColor));
    }
  }

  // Liste affichée : messages et séparateurs de jour (du plus ancien au plus récent)
  List<Object> _timeline() {
    final entries = <Object>[];
    String? lastDay;
    for (final message in _messages) {
      final date = DateLabels.parse(message['created_at']);
      if (date != null) {
        final day = '${date.year}-${date.month}-${date.day}';
        if (day != lastDay) {
          entries.add(DateLabels.dayLabel(date));
          lastDay = day;
        }
      }
      entries.add(message);
    }
    return entries;
  }

  Widget _daySeparator(String label) {
    return Center(
      child: Container(
        margin: const EdgeInsets.symmetric(vertical: 12),
        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 5),
        decoration: BoxDecoration(
          color: context.reem.surfaceHigh,
          borderRadius: BorderRadius.circular(12),
        ),
        child: Text(label, style: TextStyle(color: context.reem.textSecondary, fontSize: 12, fontWeight: FontWeight.w600)),
      ),
    );
  }

  Widget _bubble(Map<String, dynamic> message) {
    final fromMe = message['sender_id'] == _sessionManager.currentUser?['id'];
    final date = DateLabels.parse(message['created_at']);
    final body = '${message['body'] ?? ''}';

    return Align(
      alignment: fromMe ? Alignment.centerRight : Alignment.centerLeft,
      child: Container(
        margin: const EdgeInsets.only(bottom: 6),
        constraints: BoxConstraints(maxWidth: MediaQuery.sizeOf(context).width * 0.78),
        padding: const EdgeInsets.fromLTRB(12, 8, 10, 6),
        decoration: BoxDecoration(
          color: fromMe ? ReemColors.primary : context.reem.surface,
          border: fromMe ? null : Border.all(color: context.reem.border),
          borderRadius: BorderRadius.only(
            topLeft: const Radius.circular(16),
            topRight: const Radius.circular(16),
            bottomLeft: Radius.circular(fromMe ? 16 : 4),
            bottomRight: Radius.circular(fromMe ? 4 : 16),
          ),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.end,
          mainAxisSize: MainAxisSize.min,
          children: [
            Align(alignment: Alignment.centerLeft, child: _buildMessageContent(body, fromMe)),
            if (date != null)
              Padding(
                padding: const EdgeInsets.only(top: 3),
                child: Text(
                  DateLabels.clock(date),
                  style: TextStyle(
                    color: fromMe ? Colors.white70 : context.reem.textMuted,
                    fontSize: 11,
                  ),
                ),
              ),
          ],
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final photo = absoluteMediaUrl(_otherUserPhoto);
    final name = _otherUserName ?? 'Discussion';
    final timeline = _timeline().reversed.toList();

    return Scaffold(
      appBar: AppBar(
        centerTitle: false,
        titleSpacing: 0,
        title: Row(
          children: [
            CircleAvatar(
              radius: 18,
              backgroundColor: context.reem.surfaceHigh,
              backgroundImage: photo != null ? NetworkImage(photo) : null,
              child: photo == null
                  ? Text(name.isNotEmpty ? name[0].toUpperCase() : '?', style: TextStyle(color: context.reem.text, fontWeight: FontWeight.w700))
                  : null,
            ),
            const SizedBox(width: 10),
            Expanded(
              child: Text(name, maxLines: 1, overflow: TextOverflow.ellipsis),
            ),
          ],
        ),
      ),
      body: Column(
        children: [
          Expanded(
            child: _isLoading
                ? const Center(child: CircularProgressIndicator())
                : _messages.isEmpty
                    ? Center(
                        child: Text(
                          'Aucun message pour le moment.\nDis bonjour !',
                          textAlign: TextAlign.center,
                          style: TextStyle(color: context.reem.textMuted, height: 1.4),
                        ),
                      )
                    : ListView.builder(
                        controller: _scroll,
                        reverse: true, // on démarre en bas, sur le dernier message
                        padding: const EdgeInsets.fromLTRB(14, 8, 14, 8),
                        itemCount: timeline.length,
                        itemBuilder: (context, index) {
                          final entry = timeline[index];
                          if (entry is String) return _daySeparator(entry);
                          return _bubble(Map<String, dynamic>.from(entry as Map));
                        },
                      ),
          ),
          SafeArea(
            top: false,
            child: Container(
              padding: const EdgeInsets.fromLTRB(12, 8, 8, 8),
              decoration: BoxDecoration(
                color: context.reem.background,
                border: Border(top: BorderSide(color: context.reem.border)),
              ),
              child: Row(
                crossAxisAlignment: CrossAxisAlignment.end,
                children: [
                  Expanded(
                    child: TextField(
                      controller: _messageController,
                      minLines: 1,
                      maxLines: 5,
                      textCapitalization: TextCapitalization.sentences,
                      style: TextStyle(color: context.reem.text),
                      decoration: InputDecoration(
                        hintText: 'Écrire un message…',
                        contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
                        border: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(24),
                          borderSide: BorderSide.none,
                        ),
                        enabledBorder: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(24),
                          borderSide: BorderSide.none,
                        ),
                      ),
                    ),
                  ),
                  const SizedBox(width: 6),
                  GestureDetector(
                    onTap: _messageController.text.trim().isEmpty || _isSending ? null : _sendMessage,
                    child: Container(
                      width: 46,
                      height: 46,
                      decoration: BoxDecoration(
                        gradient: _messageController.text.trim().isEmpty ? null : ReemColors.gradient,
                        color: _messageController.text.trim().isEmpty ? context.reem.surfaceHigh : null,
                        shape: BoxShape.circle,
                      ),
                      child: _isSending
                          ? const Padding(
                              padding: EdgeInsets.all(13),
                              child: CircularProgressIndicator(strokeWidth: 2, color: Colors.white),
                            )
                          : Icon(
                              Icons.send_rounded,
                              color: _messageController.text.trim().isEmpty ? context.reem.textMuted : Colors.white,
                              size: 22,
                            ),
                    ),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}
