import 'package:flutter/material.dart';

import '../theme/reem_theme.dart';
import '../utils/media_url.dart';

/// Barre horizontale de stories (en haut de Communauté).
/// `groups` est la liste de StoryGroup renvoyée par StoryService.
/// Les champs sont lus de façon tolérante pour éviter toute erreur de compilation.
class StoryBar extends StatelessWidget {
  const StoryBar({
    super.key,
    required this.groups,
    required this.onOpen,
    required this.onAdd,
  });

  final List<dynamic> groups;
  final ValueChanged<int> onOpen;
  final VoidCallback onAdd;

  static String _name(dynamic g) {
    try {
      final v = g.username;
      if (v != null) return '$v';
    } catch (_) {}
    try {
      final v = g.userName;
      if (v != null) return '$v';
    } catch (_) {}
    try {
      final v = g.name;
      if (v != null) return '$v';
    } catch (_) {}
    try {
      final v = g.user['name'];
      if (v != null) return '$v';
    } catch (_) {}
    return '';
  }

  static String? _photo(dynamic g) {
    for (final getter in <dynamic Function()>[
      () => g.profilePhotoPath,
      () => g.profilePhoto,
      () => g.avatarUrl,
      () => g.avatar,
      () => g.photo,
      () => g.user['profile_photo_path'],
    ]) {
      try {
        final v = getter();
        if (v != null && '$v'.isNotEmpty) return '$v';
      } catch (_) {}
    }
    return null;
  }

  static bool _hasUnseen(dynamic g) {
    try {
      final v = g.hasUnseen;
      if (v is bool) return v;
    } catch (_) {}
    try {
      final v = g.allSeen;
      if (v is bool) return !v;
    } catch (_) {}
    return true;
  }

  Widget _bubble(BuildContext context, {required Widget child, required bool ring}) {
    return Container(
      width: 66,
      height: 66,
      padding: const EdgeInsets.all(3),
      decoration: BoxDecoration(
        shape: BoxShape.circle,
        gradient: ring ? ReemColors.gradient : null,
        color: ring ? null : context.reem.border,
      ),
      child: Container(
        decoration: BoxDecoration(
          shape: BoxShape.circle,
          color: context.reem.background,
        ),
        padding: const EdgeInsets.all(2),
        child: ClipOval(child: child),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      height: 100,
      child: ListView.builder(
        scrollDirection: Axis.horizontal,
        padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
        itemCount: groups.length + 1,
        itemBuilder: (context, index) {
          if (index == 0) {
            return GestureDetector(
              onTap: onAdd,
              child: Padding(
                padding: const EdgeInsets.symmetric(horizontal: 6),
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    _bubble(
                      context,
                      ring: false,
                      child: ColoredBox(
                        color: context.reem.surface,
                        child: Icon(Icons.add_rounded, color: context.reem.text, size: 30),
                      ),
                    ),
                    const SizedBox(height: 5),
                    SizedBox(
                      width: 70,
                      child: Text(
                        'Ma story',
                        textAlign: TextAlign.center,
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                        style: TextStyle(color: context.reem.text, fontSize: 11.5),
                      ),
                    ),
                  ],
                ),
              ),
            );
          }

          final groupIndex = index - 1;
          final group = groups[groupIndex];
          final name = _name(group);
          final photo = absoluteMediaUrl(_photo(group));

          return GestureDetector(
            onTap: () => onOpen(groupIndex),
            child: Padding(
              padding: const EdgeInsets.symmetric(horizontal: 6),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  _bubble(
                    context,
                    ring: _hasUnseen(group),
                    child: photo != null
                        ? Image.network(
                            photo,
                            fit: BoxFit.cover,
                            errorBuilder: (_, __, ___) => _initial(context, name),
                          )
                        : _initial(context, name),
                  ),
                  const SizedBox(height: 5),
                  SizedBox(
                    width: 70,
                    child: Text(
                      name,
                      textAlign: TextAlign.center,
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                      style: TextStyle(color: context.reem.text, fontSize: 11.5),
                    ),
                  ),
                ],
              ),
            ),
          );
        },
      ),
    );
  }

  Widget _initial(BuildContext context, String name) {
    return ColoredBox(
      color: context.reem.surfaceHigh,
      child: Center(
        child: Text(
          name.isNotEmpty ? name[0].toUpperCase() : '?',
          style: TextStyle(color: context.reem.text, fontWeight: FontWeight.w700, fontSize: 22),
        ),
      ),
    );
  }
}
